package exercise6;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;

class client6 {
    public static void main(String[] args) {
        try (Socket socket = new Socket("localhost", 5000);
             DataOutputStream output = new DataOutputStream(socket.getOutputStream());
             DataInputStream input = new DataInputStream(socket.getInputStream());
             Scanner scanner = new Scanner(System.in)) {

            System.out.print("Enter first number (a): ");
            int a = scanner.nextInt();
            System.out.print("Enter second number (b): ");
            int b = scanner.nextInt();

            if (a >= b) {
                System.out.println("Invalid input! Ensure that a < b.");
                return;
            }

            output.writeInt(a);
            output.writeInt(b);

            System.out.println("Even numbers in range:");
            int number;
            while ((number = input.readInt()) != -1) {
                System.out.println(number);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
