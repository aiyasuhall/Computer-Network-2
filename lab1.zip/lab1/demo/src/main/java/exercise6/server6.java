package exercise6;

import java.io.*;
import java.net.*;


// Server Class
class server6 {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            System.out.println("Server is waiting for client connection...");
            Socket socket = serverSocket.accept();
            System.out.println("Client connected");

            DataInputStream input = new DataInputStream(socket.getInputStream());
            DataOutputStream output = new DataOutputStream(socket.getOutputStream());

            int a = input.readInt();
            int b = input.readInt();

            for (int i = a; i <= b; i++) {
                if (i % 2 == 0) {
                    output.writeInt(i);
                }
            }
            output.writeInt(-1); // End signal
            System.out.println("Sent even numbers in range: [" + a + ", " + b + "]");

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

