package exercise5;

import java.io.*;
import java.net.*;
import java.util.Scanner;

// Chat Server Class
class server5 {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            System.out.println("Chat Server is running...");
            Socket socket = serverSocket.accept();
            System.out.println("Client connected");

            BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            PrintWriter output = new PrintWriter(socket.getOutputStream(), true);
            Scanner scanner = new Scanner(System.in);
            
            String received, message;
            while (true) {
                received = input.readLine();
                if (received.equalsIgnoreCase("bye")) {
                    System.out.println("Client disconnected.");
                    break;
                }
                System.out.println("Client: " + received);
                
                System.out.print("You: ");
                message = scanner.nextLine();
                output.println(message);
                
                if (message.equalsIgnoreCase("bye")) {
                    System.out.println("Chat ended by server.");
                    break;
                }
            }
            
            socket.close();
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

