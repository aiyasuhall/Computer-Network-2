package exercise4;

import java.io.*;
import java.net.*;


// Echo Server Class
class server4 {
    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            System.out.println("Echo Server is running...");
            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Client connected");

                BufferedReader input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                PrintWriter output = new PrintWriter(socket.getOutputStream(), true);

                String received;
                while ((received = input.readLine()) != null) {
                    System.out.println("Received: " + received);
                    output.println(received); // Echo back to client
                }

                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}