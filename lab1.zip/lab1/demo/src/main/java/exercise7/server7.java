package exercise7;

import java.io.*;
import java.net.*;

class server7 {
    private static int num1 = Integer.MIN_VALUE, num2 = Integer.MIN_VALUE;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            System.out.println("Server is running...");
            Socket socket = serverSocket.accept();
            System.out.println("Client connected");

            DataInputStream input = new DataInputStream(socket.getInputStream());
            DataOutputStream output = new DataOutputStream(socket.getOutputStream());
            
            while (true) {
                output.writeUTF("Menu:\n1. Input two integer numbers\n2. Maximum value of two numbers\n3. Minimum value of two numbers\n4. Exit\nChoose an option: ");
                int choice = input.readInt();
                
                switch (choice) {
                    case 1:
                        num1 = input.readInt();
                        num2 = input.readInt();
                        output.writeUTF("Numbers received successfully.");
                        break;
                    case 2:
                        if (num1 == Integer.MIN_VALUE || num2 == Integer.MIN_VALUE) {
                            output.writeUTF("Please enter two integers firstly.");
                        } else {
                            output.writeUTF("Maximum value: " + Math.max(num1, num2));
                        }
                        break;
                    case 3:
                        if (num1 == Integer.MIN_VALUE || num2 == Integer.MIN_VALUE) {
                            output.writeUTF("Please enter two integers firstly.");
                        } else {
                            output.writeUTF("Minimum value: " + Math.min(num1, num2));
                        }
                        break;
                    case 4:
                        output.writeUTF("Exit");
                        socket.close();
                        System.out.println("Server shutting down...");
                        return;
                    default:
                        output.writeUTF("Invalid choice. Please select from the menu.");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
