package exercise3;

import java.net.Socket;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class client3 {
    public static void main(String[] args) {
        try{
            Socket s = new Socket("localhost", 6666);
            DataInputStream Network_in = new DataInputStream(s.getInputStream());
            DataOutputStream Network_out = new DataOutputStream(s.getOutputStream());

            Scanner keyboard = new Scanner(System.in);
            System.out.println("Please input two integers: ");
            int data1 = keyboard.nextInt();
            int data2 = keyboard.nextInt();
            System.out.println("Please input operator: ");
            String operator = keyboard.next();
            Network_out.writeInt(data1);
            Network_out.writeInt(data2);
            Network_out.writeUTF(operator);
            int result = Network_in.readInt();
            System.out.println("Data from server3: " + result);

            s.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
