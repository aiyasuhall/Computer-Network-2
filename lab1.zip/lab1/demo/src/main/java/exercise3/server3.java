package exercise3;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class server3 {
    public static void main(String[] args) {
        try{
            ServerSocket ss = new ServerSocket(6666);
            Socket s = ss.accept();
            DataInputStream Network_in = new DataInputStream(s.getInputStream());
            DataOutputStream Network_out = new DataOutputStream(s.getOutputStream());

            int data1 = Network_in.readInt();
            int data2 = Network_in.readInt();
            String operator = Network_in.readUTF();
            int result = 0;
            switch(operator){
                case "+":
                    result = data1 + data2;
                    break;
                case "-":
                    result = data1 - data2;
                    break;
                case "*":
                    result = data1 * data2;
                    break;
                case "/":
                    result = data1 / data2;
                    break;
                default:
                    System.out.println("Invalid operator");
            }
            Network_out.writeInt(result);

            s.close();
            ss.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
